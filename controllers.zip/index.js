// index.js
const express = require('express');
const app = express();
const cors = require('cors');
app.use(express.json());
app.use(cors());
const contactUsController = require('./controllers/contactUs');

app.get('/',(req,res)=>{res.send('running')})

app.post('/sendmail', contactUsController.postMessage);

const port = 8000;
app.listen(port, () => {
    console.log(`Connected on port ${port}`);
});
